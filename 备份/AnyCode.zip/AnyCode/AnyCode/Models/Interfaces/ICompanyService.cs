﻿using System;

namespace AnyCode
{
    public interface ISysCompanyService : IDisposable
    {
      
    }
}