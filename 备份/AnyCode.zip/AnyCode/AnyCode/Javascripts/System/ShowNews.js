﻿function backList() {
    var url = '/News/NewsList';
    BaseBackPage("查看公告", "公告列表", url);
}